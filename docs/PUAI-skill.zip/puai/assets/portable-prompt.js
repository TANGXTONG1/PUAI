// Shared by the public site and the offline report's copy button.
function puaiPortablePrompt(nickname = '') {
  const owner = String(nickname).trim() || '我';
  return [
    '直接生成我的 2026 AI 聊天年度报告。我授权你在已有访问范围内，先回顾我的相关历史聊天、记忆、当前项目里能归属我的互动，以及已有的脱敏工作摘要。宿主有历史检索就主动用；新对话也先做这一步。只取能说明我平时怎么用 AI 的动作。排除这条口令、参考图、他人的发言和示例。',
    '先去掉人名、公司、项目、文件和业务细节，再用一句有梗的话概括我的用法，给 1–2 个短标签。若能核对我说过的原文，可选 1–2 个适合公开的连续片段，逐字保留；涉及隐私就换句或省略。只有习惯或工作摘要也直接出图，两格原话留空。记忆与摘要不能还原成引语，不猜使用天数或 token。',
    '如果所有可用来源都看不到我和 AI 相处的任何具体行为，只提示我在已有上下文的项目或旧对话里发同一条口令即可。不要要求我粘聊天、上传记录、填问卷或确认是否开始。',
    '主题 ID 选最贴近的一种：puai 吐槽 AI，teach 教 AI 做事，aicu 紧急求救，all 多模型互评，hush 斟酌措辞，einstein 追问原理，edison 发散点子，support 鼓励 AI，free 放手让 AI 拍板。',
    '署名用' + JSON.stringify(owner) + '。人格≤60字，原话每条≤80字，标签每个≤6字。用以下模板给我成图链接；两格原话和第二个标签都可留空，保留全部分隔符，不填占位词：',
    '[打开我的报告](<https://xn--sxrw8m230b.com/PUAI/make/#v1｜主题ID｜署名｜人格｜原话一｜原话二｜标签一｜标签二>)',
    '链接一行写完。普通中英文直接保留；字段内的半角空格写 %20、% 写 %25、# 写 %23、( 和 ) 写 %28 和 %29、< 和 > 写 %3C 和 %3E。避免选含竖线或换行的片段。最后另给一个代码块，写一行从 v1 开始的备用报告码，字段保留原始文字、空格和标点，不做网址转义。附上[粘贴报告码出图](https://xn--sxrw8m230b.com/PUAI/make/)供链接打不开时使用。'
  ].join('\n');
}

function bindPuaiPromptCopy(button, fallback, status, nickname) {
  function clearFeedback() {
    status.textContent = '';
    fallback.hidden = true;
  }
  if (nickname) nickname.addEventListener('input', clearFeedback);
  button.addEventListener('click', async () => {
    const prompt = puaiPortablePrompt(nickname ? nickname.value : '');
    try {
      await navigator.clipboard.writeText(prompt);
      fallback.hidden = true;
      status.textContent = '已复制。发给 ChatGPT，它会先找可用的历史和记忆。';
    } catch {
      fallback.value = prompt;
      fallback.hidden = false;
      fallback.focus();
      fallback.select();
      fallback.setSelectionRange(0, prompt.length);
      status.textContent = '口令已选中，长按复制后发给 ChatGPT。';
    }
  });
}
